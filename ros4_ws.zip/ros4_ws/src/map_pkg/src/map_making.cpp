#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/visualization/pcl_visualizer.h>

pcl::visualization::PCLVisualizer::Ptr viewer(new pcl::visualization::PCLVisualizer("Map Viewer"));

void pointCloudCallback(const sensor_msgs::PointCloud2ConstPtr& msg)
{
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
  pcl::fromROSMsg(*msg, *cloud);

  viewer->removeAllPointClouds();
  viewer->addPointCloud<pcl::PointXYZ>(cloud, "map_cloud");
  viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 1, "map_cloud");
  viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_OPACITY, 0.5, "map_cloud"); // 设置点云透明度为0.5
  viewer->spinOnce();
}

int main(int argc, char** argv)
{
  ros::init(argc, argv, "map_building_node");
  ros::NodeHandle nh;

  viewer->setBackgroundColor(0, 0, 0);  // 设置窗口背景颜色为黑色
  viewer->initCameraParameters();       // 初始化相机参数

  ros::Subscriber sub = nh.subscribe<sensor_msgs::PointCloud2>("/rslidar_points", 1, pointCloudCallback);

  while (ros::ok())
  {
    ros::spinOnce();
  }

  return 0;
}

