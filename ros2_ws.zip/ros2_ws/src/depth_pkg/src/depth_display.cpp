#include <ros/ros.h>
#include <rosbag/bag.h>
#include <rosbag/view.h>
#include <sensor_msgs/Image.h>
#include <opencv2/opencv.hpp>
#include <cv_bridge/cv_bridge.h>
#include <opencv2/highgui/highgui.hpp>


int main(int argc, char** argv)
{
  // 初始化ROS节点
  ros::init(argc, argv, "bag_depth_viewer");
  ros::NodeHandle nh;

  // 打开.bag文件
  rosbag::Bag bag;
  bag.open("/home/yx/ros_ws/src/camera_pkg/src/all.bag", rosbag::bagmode::Read);

  // 创建一个话题过滤器，只接收/camera/depth/image_rect_raw的消息
  rosbag::View view(bag, rosbag::TopicQuery("/camera/depth/image_rect_raw"));

  // 遍历消息并显示图像
  for (rosbag::MessageInstance const msg : view)
  {
    // 将ROS消息转换为sensor_msgs::Image消息
    sensor_msgs::Image::ConstPtr image_msg = msg.instantiate<sensor_msgs::Image>();
    if (image_msg == nullptr)
      continue;

    // 将sensor_msgs::Image转换为OpenCV图像
    cv_bridge::CvImagePtr cv_image;
    try
    {
      cv_image = cv_bridge::toCvCopy(image_msg, sensor_msgs::image_encodings::TYPE_16UC1);
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
      continue;
    }

    // 显示图像
    cv::imshow("Depth Viewer", cv_image->image);
    cv::waitKey(1);
  }

  // 关闭.bag文件和OpenCV窗口
  bag.close();
  cv::destroyAllWindows();

  return 0;
}

