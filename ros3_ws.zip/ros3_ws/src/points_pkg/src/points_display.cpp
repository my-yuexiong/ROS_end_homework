#include <ros/ros.h>
#include <rosbag/bag.h>
#include <rosbag/view.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/visualization/cloud_viewer.h>
#include <thread>

int main(int argc, char** argv)
{
  // 初始化ROS节点
  ros::init(argc, argv, "bag_points_viewer");
  ros::NodeHandle nh;

  // 打开.bag文件
  rosbag::Bag bag;
  bag.open("/home/yx/ros_ws/src/camera_pkg/src/all.bag", rosbag::bagmode::Read);

  // 创建一个话题过滤器，只接收/rslidar_points的消息
  rosbag::View view(bag, rosbag::TopicQuery("/rslidar_points"));

  // 创建PCL可视化窗口
  pcl::visualization::PCLVisualizer::Ptr viewer(new pcl::visualization::PCLVisualizer("Point Cloud Viewer"));

  // 创建点云显示的标识符
  int cloud_index = 0;

  // 遍历消息并显示点云
  for (rosbag::MessageInstance const msg : view)
  {
    // 将ROS消息转换为sensor_msgs::PointCloud2消息
    sensor_msgs::PointCloud2::ConstPtr cloud_msg = msg.instantiate<sensor_msgs::PointCloud2>();
    if (cloud_msg == nullptr)
      continue;

    // 将sensor_msgs::PointCloud2转换为PCL点云数据类型
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::fromROSMsg(*cloud_msg, *cloud);

    // 将点云添加到可视化窗口并设置颜色
    viewer->addPointCloud<pcl::PointXYZ>(cloud, "cloud" + std::to_string(cloud_index));
    viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR, 1.0, 0.0, 0.0, "cloud" + std::to_string(cloud_index));

    // 更新可视化窗口
    viewer->spinOnce(100);
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    ros::spinOnce();

    // 移除上一帧的点云
    viewer->removePointCloud("cloud" + std::to_string(cloud_index));
    cloud_index++;
  }

  // 关闭.bag文件和PCL可视化窗口
  bag.close();
  viewer->close();

  return 0;
}

